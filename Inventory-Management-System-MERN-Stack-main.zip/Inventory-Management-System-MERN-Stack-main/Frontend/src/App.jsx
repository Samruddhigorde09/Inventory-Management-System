import React from 'react'

function App() {
  return (
    <div className='text-xl'>App</div>
  )
}

export default App
import React from 'react'

function PopUpComponenet() {
  return (
    <div className=' w-fit h-full backdrop-blur-sm bg-yellow-50/10'></div>
  )
}

export default PopUpComponenet
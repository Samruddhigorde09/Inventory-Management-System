import React from 'react'

function ChangeRolePopup() {
  return (
    <div>ChangeRolePopup</div>
  )
}

export default ChangeRolePopup